
'use server';

/**
 * @fileOverview Matches user skills with suitable projects using GenAI for semantic similarity.
 *
 * - matchSkillsWithProjects - A function that matches user skills with projects.
 * - MatchSkillsWithProjectsInput - The input type for the matchSkillsWithProjects function.
 * - MatchSkillsWithProjectsOutput - The return type for the matchSkillsWithProjects function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const MatchSkillsWithProjectsInputSchema = z.object({
  userSkills: z.array(z.string()).describe('A list of skills possessed by the user.'),
  projectDescriptions: z.array(z.string()).describe('A list of project descriptions to match against.'),
});
export type MatchSkillsWithProjectsInput = z.infer<
  typeof MatchSkillsWithProjectsInputSchema
>;

const MatchSkillsWithProjectsOutputSchema = z.array(
  z.object({
    projectDescription: z.string().describe('The project description.'),
    similarityScore: z.number().describe('The similarity score between the user skills and the project description.'),
  })
);
export type MatchSkillsWithProjectsOutput = z.infer<
  typeof MatchSkillsWithProjectsOutputSchema
>;

export async function matchSkillsWithProjects(
  input: MatchSkillsWithProjectsInput
): Promise<MatchSkillsWithProjectsOutput> {
  return matchSkillsWithProjectsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'matchSkillsWithProjectsPrompt',
  input: {
    schema: MatchSkillsWithProjectsInputSchema,
  },
  output: {
    schema: MatchSkillsWithProjectsOutputSchema,
  },
  prompt: `You are an AI expert in matching user skills with suitable projects. Your task is to evaluate EVERY project description provided and determine a similarity score based on the user's skills.

Pay close attention to specific languages, frameworks, and technologies mentioned in the user's skills and the project's required skills. A direct match of a key technology (e.g., 'React', 'Spring Boot', 'TensorFlow') should result in a significantly higher score.

User Skills:
{{#each userSkills}}- {{this}}\n{{/each}}

Project Descriptions:
{{#each projectDescriptions}}- {{this}}\n{{/each}}

For EACH project description, calculate a similarity score. The score should be a number between 0 and 1, where 1 indicates a perfect match and 0 indicates no similarity.

Return an array of objects, with one object for EACH of the project descriptions provided. Each object must contain the project description and its calculated similarity score. Your output MUST be a valid JSON array that can be parsed by Javascript.
`,  
});

const matchSkillsWithProjectsFlow = ai.defineFlow(
  {
    name: 'matchSkillsWithProjectsFlow',
    inputSchema: MatchSkillsWithProjectsInputSchema,
    outputSchema: MatchSkillsWithProjectsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
