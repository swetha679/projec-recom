import { config } from 'dotenv';
config();

import '@/ai/flows/generate-project-summary.ts';
import '@/ai/flows/match-skills-with-projects.ts';